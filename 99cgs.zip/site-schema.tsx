import type { ReactElement } from "react";

const SITE_URL = "https://99cgs.in";

const ORGANIZATION_ID = `${SITE_URL}/#organization`;
const WEBSITE_ID = `${SITE_URL}/#website`;

type Breadcrumb = {
  name: string;
  url: string;
};

type ServiceInfo = {
  name: string;
  description: string;
  url: string;
};

type ArticleInfo = {
  headline: string;
  description: string;
  url: string;
  image?: string;
  datePublished?: string;
  dateModified?: string;
  authorName?: string;
};

type FAQItem = {
  question: string;
  answer: string;
};

type SiteSchemaProps = {
  includeSiteEntities?: boolean;
  page?: {
    name: string;
    description: string;
    path: string;
    type?:
      | "WebPage"
      | "AboutPage"
      | "ContactPage"
      | "CollectionPage";
    service?: ServiceInfo;
    article?: ArticleInfo;
    breadcrumbs?: Breadcrumb[];
    faqs?: FAQItem[];
  };
};

export default function SiteSchema({
  includeSiteEntities = false,
  page,
}: SiteSchemaProps): ReactElement {
  const graph: Record<string, unknown>[] = [];

  // 1. Main brand identity
  if (includeSiteEntities) {
    graph.push({
      "@type": "Organization",
      "@id": ORGANIZATION_ID,
      "name": "99CGS",
      "url": SITE_URL,
      "email": "99cgsaiagency@gmail.com",
      "description":
        "99CGS is an AI-powered content and growth agency helping businesses create smarter content, improve digital visibility, generate leads and build intelligent growth systems.",
      "slogan": "Growth is not accidental. It's engineered.",
      "logo": {
        "@type": "ImageObject",
        "url": `${SITE_URL}/logo.png`,
      },
      "brand": {
        "@type": "Brand",
        "name": "99CGS",
      },
      "knowsAbout": [
        "AI Content Creation",
        "AI Video Production",
        "Social Media Growth",
        "Performance Marketing",
        "Search Engine Optimization",
        "Answer Engine Optimization",
        "Generative Engine Optimization",
        "AI Automation",
        "Lead Generation",
        "CRM Automation",
        "Website Development",
        "Conversion Rate Optimization",
      ],
    });

    // 2. Website identity
    graph.push({
      "@type": "WebSite",
      "@id": WEBSITE_ID,
      "url": SITE_URL,
      "name": "99CGS",
      "description":
        "AI-powered content, marketing, automation and business growth solutions.",
      "publisher": {
        "@id": ORGANIZATION_ID,
      },
      "inLanguage": "en",
    });
  }

  if (page) {
    const pageUrl = `${SITE_URL}${page.path}`;

    // 3. Current webpage
    graph.push({
      "@type": page.type || "WebPage",
      "@id": `${pageUrl}#webpage`,
      "url": pageUrl,
      "name": page.name,
      "description": page.description,
      "isPartOf": {
        "@id": WEBSITE_ID,
      },
      "about": {
        "@id": ORGANIZATION_ID,
      },
      "publisher": {
        "@id": ORGANIZATION_ID,
      },
      "inLanguage": "en",
    });

    // 4. Individual service
    if (page.service) {
      graph.push({
        "@type": "Service",
        "@id": `${page.service.url}#service`,
        "name": page.service.name,
        "description": page.service.description,
        "url": page.service.url,
        "provider": {
          "@id": ORGANIZATION_ID,
        },
        "mainEntityOfPage": {
          "@id": `${pageUrl}#webpage`,
        },
      });
    }

    // 5. Blog article
    if (page.article) {
      const article = page.article;

      graph.push({
        "@type": "BlogPosting",
        "@id": `${article.url}#article`,
        "headline": article.headline,
        "description": article.description,
        "mainEntityOfPage": article.url,
        "url": article.url,
        "publisher": {
          "@id": ORGANIZATION_ID,
        },
        ...(article.image ? { image: [article.image] } : {}),
        ...(article.datePublished
          ? { datePublished: article.datePublished }
          : {}),
        ...(article.dateModified
          ? { dateModified: article.dateModified }
          : {}),
        ...(article.authorName
          ? {
              author: {
                "@type": "Person",
                "name": article.authorName,
              },
            }
          : {}),
      });
    }

    // 6. Breadcrumb navigation
    if (page.breadcrumbs && page.breadcrumbs.length >= 2) {
      graph.push({
        "@type": "BreadcrumbList",
        "@id": `${pageUrl}#breadcrumbs`,
        "itemListElement": page.breadcrumbs.map(
          (crumb, index) => ({
            "@type": "ListItem",
            "position": index + 1,
            "name": crumb.name,
            "item": crumb.url,
          })
        ),
      });
    }

    // 7. Visible FAQ content
    if (page.faqs && page.faqs.length > 0) {
      graph.push({
        "@type": "FAQPage",
        "@id": `${pageUrl}#faq`,
        "mainEntity": page.faqs.map((faq) => ({
          "@type": "Question",
          "name": faq.question,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": faq.answer,
          },
        })),
      });
    }
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@graph": graph,
  };

  const safeJsonLd = JSON.stringify(jsonLd).replace(
    /</g,
    "\\u003c"
  );

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{
        __html: safeJsonLd,
      }}
    />
  );
}
